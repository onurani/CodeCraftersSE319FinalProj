//Author: Ozair Nurani
//ISU Netid : onurani@iastate.edu
//Date :  April 26, 2024

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";

function App() {
  // GET all items
  const [dataF, setDataF] = useState({});
  const [view, setView] = useState("browse");
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [cart, setCart] = useState([]);
  const [cartTotal, setCartTotal] = useState(0);
    
  const onSubmit = (data) => {
      setDataF(data); 
      setView("ViewSummary");
  };
  
  const updateHooks = () => {
      setView("Getcatalog");
      setDataF({});
      setCart([]);
  };

  const addToCart = (el) => {  
    setCart([...cart, el]);
};

const removeFromCart = (el) => {
    let updatedItem = [...cart];
    updatedItem = updatedItem.filter((cartItem) => cartItem.id !== el.id);
    setCart(updatedItem);
    let itemFound = false;
    const updatedCart = cart.filter((cartItem) => {
        if (cartItem.id === el.id && !itemFound) {
            itemFound = true;
            return false;
        }
        return true;
    });
    if (itemFound) {
        setCart(updatedCart);
    }
};

function howManyofThis(id) {
    let returner = cart.filter((cartItem) => cartItem.id === id);
    return returner.length;
}

const total = () => {
  let totalVal = 0;
  for (const item of cart) {
      totalVal += item.price;
  }
  setCartTotal(totalVal);
};

useEffect(() => {
total();
}, [cart]);

  const Getcatalog = () => {
    // Define hooks
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    //const [cart, setCart] = useState(currqntty?.innerHTML);
    
    // useEffect to load products when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          console.log("Show Catalog of Products :", data);
          setProducts(data);
        });
    }, []);

    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <button onClick={() => navigate("/AboutUs")}>
          About Us
        </button>


        {/* Show all products using map */}
        {products.map((el) => (
          
          <div key={el.id}>
            <img src={el.image} alt="product" width={75} />
            <div><button onClick={() => navigate(`/${el.title}`)} className="btn btn-secondary">GoToCourse</button></div>
            
            <div><b>Title</b>: {el.title} <br /></div>
            
            <div><b>Price</b>: {el.price}</div>
            <div><b>Description</b>: {el.description}</div>
            <div><b>Category</b>: {el.category}</div>
            <div className="col">
                        <button type="button" variant="light" onClick={() => removeFromCart(el)} > - </button>{" "}
                        <button type="button" variant="light" onClick={() => addToCart(el)}> + </button>
            </div>
            <div className="col">
                        ${el.price} <span className="close">&#10005;</span> {howManyofThis(el.id)}
                    </div><br /><br />
          </div>
        ))}
        <button onClick={() => navigate("/CartView")} className="btn btn-primary">Checkout</button><br /><br /><br />
      </div>
    );
  };


  /*
  // GET one item
  const Getcatalogid = () => {
    // Define hooks
    const [oneProduct, setOneProduct] = useState([]);
    const navigate = useNavigate();
    const [id, setId] = useState("");

    // useEffect to load catalog once HOOK id is modified
    useEffect(() => {
      if (id) {
        fetch(`http://127.0.0.1:3001/language/${id}`)
          .then((response) => response.json())
          .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
          });
      }
    }, [id]); // Fetch only when id changes

    // return
    return (
      <div>
        {}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <br />
        <input
          type="text"
          placeholder="Enter ID"
          onChange={(e) => setId(e.target.value)}
        />

        {}
        {oneProduct.map((el) => (
          <div key={el.id}>
            <img src={el.image} alt="product" width={75} />
            <div><b>Title</b>: {el.title}</div>
            <div><b>Price</b>: {el.price}</div>
            <div><b>Description</b>: {el.description}</div>
            <div><b>Category</b>: {el.category}</div>
            <div><b>Quantity</b>: {el.Quantity}</div>
          </div>
        ))}
      </div>
    );
  };
  */



  const Getcatalogid = () => {
    // Define hooks
    const [oneProduct, setOneProduct] = useState({});
    const navigate = useNavigate();
    const [id, setId] = useState("");

    // useEffect to load catalog once HOOK id is modified
    useEffect(() => {
      if (id) {
        fetch(`http://127.0.0.1:3001/language/${id}`)
          .then((response) => response.json())
          .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
          });
      }
    }, [id]); // Fetch only when id changes

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>GET Item by Id</button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <br />
        <input
          type="text"
          placeholder="Enter ID"
          onChange={(e) => setId(e.target.value)}
        />

        {/* Show one product using map */}
        {<div key={oneProduct.id}>
            <img src={oneProduct.image} alt="product" width={75} />
            <div>Title: {oneProduct.title}</div>
            <div>Category: {oneProduct.category}</div>
            <div>Price: {oneProduct.price}</div>
            <div>Quantity: {oneProduct.Quantity}</div>
          </div>
        }
      </div>
    );
  };

  // POST a new item
  const Postcatalog = () => {
    // Define HOOKS
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });

    // Function to add input in formData HOOK using operator ...
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    };

    // Function to fetch backend for POST - it sends data in BODY
    const handleSubmit = (e) => {
      e.preventDefault();
      console.log(e.target.value);
      fetch("http://127.0.0.1:3001/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log(data);
          alert("Item added successfully!");
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    }; // end handleOnSubmit

    //return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Form to input data */}
        <form onSubmit={handleSubmit}>
          <h1>Post a New Product</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // PUT - Modify an item
  const Putcatalog = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });
    console.log(formData);

    const handleChange = (e) => {
      console.log(formData);
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
      console.log(formData);
    };

    const handleSubmit = (e) => {
      console.log(formData);
      e.preventDefault();
      const id = formData.id; // Extract ID from formData
      fetch(`http://localhost:3001/change2/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(
              `PUT request failed with status ${response.status}`
            );
          }
          return response.json();
        })
        .then((data) => {
          console.log("PUT request successful:", data);
          alert("Item updated successfully!");
        })
        .catch((error) => {
          console.error("Error updating item:", error);
          alert("Error updating item: " + error.message); // Display alert if there's an error
        });
    };

    return (
      <div>
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <form onSubmit={handleSubmit}>
          <h1>Put (Modify) an Existing Product by ID</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <p>Enter an ID to be updated with your new information</p>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // DELETE - Delete an item
  const Deletecatalog = () => {
    // Define HOOKS
    const [products, setProducts] = useState([
      {
        id: "",
        title: "",
        price: "",
        description: "",
        category: "",
        image: "",
        Quantity: ""
      },
    ]);
    const [index, setIndex] = useState(0);
    const navigate = useNavigate();

    // useEffect to load catalog when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          setProducts(data);
          console.log("Load initial Catalog of Products in DELETE :", data);
        });
    }, []);

    // Function to review products like carousel
    function getOneByOneProductNext() {
      if (products.length > 0) {
        if (index === products.length - 1) setIndex(0);
        else setIndex(index + 1);
      }
    }

    function getOneByOneProductPrev() {
      if (products.length > 0) {
        if (index === 0) setIndex(products.length - 1);
        else setIndex(index - 1);
      }
    }

    // Delete de product by its id <- id is Hook
    const deleteOneProduct = (id) => {
        console.log("I am here");
      console.log("Product to delete :", id);
      fetch("http://localhost:3001/deleteone/" + id, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: id }),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log("Delete a product completed : ", id);
          console.log(data);
          // reload products from the local products array
          const newProducts = products.filter((product) => product.id !== id);
          setProducts(newProducts);
          setIndex(0);
          // show alert
          if (data) {
            const key = Object.keys(data);
            const value = Object.values(data);
            alert(key + value);
          }
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    };

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Buttons to simulate carousel */}
        <h3>Delete one product:</h3>
        <button onClick={() => getOneByOneProductPrev()}>Prev</button>
        <button onClick={() => getOneByOneProductNext()}>Next</button>
        <button onClick={() => deleteOneProduct(products[index].id)}>
          Delete
        </button>

        {/* Show product properties, one by one */}
        <div key={products[index].id}>
          <img src={products[index].image} alt="product" width={75} /> <br />
          Id:{products[index].id} <br />
          Title: {products[index].title} <br />
          Price: {products[index].price} <br />
          Description: {products[index].description} <br />
          Category: {products[index].category} <br />
          Quantity :{products[index].Quantity} <br />
        </div>
      </div>
    );
  };


  const Payment = () => {
    const navigate = useNavigate();

    return (
        <div>
            <form onSubmit={handleSubmit(onSubmit)} className="container mt-5">
                {/* Payment Form */}
                <div className="form-group">
                    <input {...register("fullName", { required: true })} placeholder="Full Name" className="form-control" />
                    {errors.fullName && <p className="text-danger">Full Name is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("email", { required: true, pattern: /^\S+@\S+$/i })} name="email" type="email" placeholder="Email" className="form-control" />
                    {errors.email && <p className="text-danger">Email is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("creditCard", { required: true})} placeholder="Credit Card" className="form-control" />
                    {errors.creditCard && <p className="text-danger">Credit Card is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address", { required: true })} placeholder="Address" className="form-control" />
                    {errors.address && <p className="text-danger">Address is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address2")} placeholder="Address 2" className="form-control" />
                </div><br />

                <div className="form-group">
                    <input {...register("city", { required: true })} placeholder="City" className="form-control" />
                    {errors.city && <p className="text-danger">City is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("state", { required: true })} placeholder="State" className="form-control" />
                    {errors.state && <p className="text-danger">State is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("zip", { required: true })} placeholder="Zip" required pattern="^\d{5}$" className="form-control"/>
                    {errors.zip && <p className="text-danger">Zip is required.</p>}
                </div><br />

                <button onClick={() => navigate("/ViewSummary")} className="btn btn-primary">Order</button>
                <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
            </form>
        </div>
    );
};



  const CartView = () => {
    console.log(cart);
    const allitems = Array.from(new Set(cart.map(el => el.id)))
        .map(id => {
            return {
                ...cart.find(el => el.id === id),
                quantity: cart.filter(el => el.id === id).length
            };
        });

    const cartItems = allitems.map((el, index) => (
        <div key={index}>
            <div className="row border-top border-bottom" key={el.id}>
                <div className="row main align-items-center">
                    <div className="col-1">
                        <img className="img-fluid" src={el.image} width={75} />
                    </div>
                    <div className="col-1">
                        <div className="row text-muted">{el.title}</div>
                        <div className="row">{el.category}</div>
                    </div>
                    <div className="col-1">
                        ${el.price} <span className="close">&#10005;</span> {el.quantity}
                    </div>
                </div>
            </div>
        </div>
    ));

    //displays items selected in browse, total price, and payment form
    return (
        <div>
            <h1><b>Shopping Cart</b></h1>
            <p>View your cart items</p>
            <p><strong>Order total: ${cartTotal}</strong></p>
            <div>{cartItems}</div><br />
            <h1><b>Payment:</b></h1>
            <Payment />
        </div>
    );
};


const ViewSummary = () => {
  const navigate = useNavigate();
  const allitems = Array.from(new Set(cart.map(el => el.id)))
      .map(id => {
          return {
              ...cart.find(el => el.id === id),
              quantity: cart.filter(el => el.id === id).length
          };
      });

  const cartItems = allitems.map((el, index) => (
      <div key={index}>
          <div className="row border-top border-bottom" key={el.id}>
              <div className="row main align-items-center">
                  <div className="col-1">
                      <img className="img-fluid" src={el.image} width={75} />
                  </div>
                  <div className="col-1">
                      <div className="row text-muted">{el.title}</div>
                      <div className="row">{el.category}</div>
                  </div>
                  <div className="col-1">
                      ${el.price} <span className="close">&#10005;</span> {el.quantity}
                  </div>
              </div>
          </div>
      </div>
  ));

 
  return (
      <div>
          <h1><b>Order summary</b></h1>
          <p><strong>Order total: ${cartTotal}</strong></p>

          <h4>Payment summary:</h4>
          <p>{dataF.fullName}</p>
          <p>{dataF.email}</p>
          <p>{dataF.creditCard}</p>
          <p>{dataF.address}</p>
          <p>{dataF.address2}</p>
          <p>{dataF.city}, {dataF.state} {dataF.zip} </p><br />

          <h4>Purchased:</h4>
          <div>{cartItems}</div><br />
          <button onClick={() => navigate("/CartView")} className="btn btn-primary">Back to Cart</button>
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
      </div>
  );
};

const JavaScript = () => {
  const navigate = useNavigate();
  return (
      <div>
        <label><b>This is some sample JavaScript</b></label><br />
        <label>let a = 3;</label><br />
        <label>let x = (100 + 50) * a;</label><br />
        <label>Result is 450</label><br /><br />
        <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>






        <div id="content" class="container mt-4">
        <div id="math-question">
        <h2>Math Question</h2>

        <label for="user-inputx">int x = </label>
        <input type="number" id="user-inputx" required></input>
        <label for="user-inputy">int y = </label>
        <input type="number" id="user-inputy" required></input>
        <label for="javamath">Operation</label>
        <select id="javamath"></select>
        <button type="submit">Calculate</button>

        <div id="math-result">
        Result: <span id="math-result-val"></span>
        </div>
        <div id="mathimage">   
        <img src="./myotherimages/javamathlogo.jpg" alt="Math Equation"></img>
        </div>    
        <div id="mathver">
            
        </div>
        <div id="moremath">
            
        </div>
        </div>

        <div id="string-question" class="mt-4">
        <h2>String Question</h2>
    
        <label for="user-stringinputx">Please input first word: </label>
        <input type="text" id="user-stringinputx" required></input>
        <label for="javastring">Operation</label>
        <select id="javastring"></select>
        <label for="user-stringinputy">Please input second word: </label>
        <input type="text" id="user-stringinputy" required></input>
        <button type="submit">Evaluate</button>
    
        <div id="string-result">
        Result: <span id="string-result-val"></span>
        </div>
        <div id="stringimage">   
            <img src="./myotherimages/javastringslogo.jpg" alt="String Equation"></img>
        </div>    
        <div id="stringver">
            
        </div>
        <div id="morestring">
            
        </div>
        </div>
        </div>
    </div>
  );
};




const Java = () => {
    const navigate = useNavigate();
    return (
        <div>
          <label><b>This is some sample Java</b></label><br />
          <label>int a = 3;</label><br />
          <label>int x = (100 + 50) * a;</label><br />
          <label>System.out.println(x) = 450</label><br /><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};





const AboutUs = () => {
    const navigate = useNavigate();
    return (
        <div>
          <label><b>By Ozair Nurani and Reza Choudhury </b></label><br />
          <label>Code Crafters</label><br />
          <label>We are both sophomores majoring in Software Engineering</label><br />
          <label>onurani@iastate.edu and zaza@iastate.edu</label><br /><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>  
        </div>
  
  
  
  
    );
  };
  

  return (
    <Router>
      <Routes>
        <Route path="/getcatalog" element={<Getcatalog />} />
        <Route path="/getcatalogid" element={<Getcatalogid />} />
        <Route path="/postcatalog" element={<Postcatalog />} />
        <Route path="/putcatalog" element={<Putcatalog />} />
        <Route path="/deletecatalog" element={<Deletecatalog />} />
        <Route path="/CartView" element={<CartView />} />
        <Route path="/ViewSummary" element={<ViewSummary />} />
        <Route path="/JavaScript" element={<JavaScript />} />
        <Route path="/Java" element={<Java />} />
        <Route path="/AboutUs" element={<AboutUs />} />
        <Route path="/" element={<Getcatalog />} /> {/* Default view */}
      </Routes>
    </Router>
  );
} // App end

export default App;