//Author: Ozair Nurani
//ISU Netid : onurani@iastate.edu
//Date :  April 26, 2024

import { useState, useEffect } from "react";
import "./App.css";
import { useForm } from "react-hook-form";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";

function App() {
  // GET all items
  const [dataF, setDataF] = useState({});
  const [view, setView] = useState("browse");
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [cart, setCart] = useState([]);
  const [cartTotal, setCartTotal] = useState(0);
    
  const onSubmit = (data) => {
      setDataF(data); 
      setView("ViewSummary");
  };
  
  const updateHooks = () => {
      setView("Getcatalog");
      setDataF({});
      setCart([]);
  };

  const addToCart = (el) => {  
    setCart([...cart, el]);
};

const removeFromCart = (el) => {
    let updatedItem = [...cart];
    updatedItem = updatedItem.filter((cartItem) => cartItem.id !== el.id);
    setCart(updatedItem);
    let itemFound = false;
    const updatedCart = cart.filter((cartItem) => {
        if (cartItem.id === el.id && !itemFound) {
            itemFound = true;
            return false;
        }
        return true;
    });
    if (itemFound) {
        setCart(updatedCart);
    }
};

function howManyofThis(id) {
    let returner = cart.filter((cartItem) => cartItem.id === id);
    return returner.length;
}

const total = () => {
  let totalVal = 0;
  for (const item of cart) {
      totalVal += item.price;
  }
  setCartTotal(totalVal);
};

useEffect(() => {
total();
}, [cart]);

  const Getcatalog = () => {
    // Define hooks
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    //const [cart, setCart] = useState(currqntty?.innerHTML);
    
    // useEffect to load products when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          console.log("Show Catalog of Products :", data);
          setProducts(data);
        });
    }, []);

    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <button onClick={() => navigate("/AboutUs")}>
          About Us
        </button>


        {/* Show all products using map */}
        {products.map((el) => (
          
          <div key={el.id}>
            <img src={el.image} alt="product" width={75} />
            <div><button onClick={() => navigate(`/${el.title}`)} className="btn btn-secondary">GoToCourse</button></div>
            
            <div><b>Title</b>: {el.title} <br /></div>
            
            <div><b>Price</b>: {el.price}</div>
            <div><b>Description</b>: {el.description}</div>
            <div><b>Category</b>: {el.category}</div>
            <div className="col">
                        <button type="button" variant="light" onClick={() => removeFromCart(el)} > - </button>{" "}
                        <button type="button" variant="light" onClick={() => addToCart(el)}> + </button>
            </div>
            <div className="col">
                        ${el.price} <span className="close">&#10005;</span> {howManyofThis(el.id)}
                    </div><br /><br />
          </div>
        ))}
        <button onClick={() => navigate("/CartView")} className="btn btn-primary">Checkout</button><br /><br /><br />
      </div>
    );
  };




  const Getcatalogid = () => {
    // Define hooks
    const [oneProduct, setOneProduct] = useState({});
    const navigate = useNavigate();
    const [id, setId] = useState("");

    // useEffect to load catalog once HOOK id is modified
    useEffect(() => {
      if (id) {
        fetch(`http://127.0.0.1:3001/language/${id}`)
          .then((response) => response.json())
          .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
          });
      }
    }, [id]); // Fetch only when id changes

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>GET Item by Id</button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <br />
        <input
          type="text"
          placeholder="Enter ID"
          onChange={(e) => setId(e.target.value)}
        />

        {/* Show one product using map */}
        {<div key={oneProduct.id}>
            <img src={oneProduct.image} alt="Product" width={75} />
            <div>Title: {oneProduct.title}</div>
            <div>Category: {oneProduct.category}</div>
            <div>Price: {oneProduct.price}</div>
            <div>Quantity: {oneProduct.Quantity}</div>
          </div>
        }
      </div>
    );
  };

  // POST a new item
  const Postcatalog = () => {
    // Define HOOKS
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });

    // Function to add input in formData HOOK using operator ...
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    };

    // Function to fetch backend for POST - it sends data in BODY
    const handleSubmit = (e) => {
      e.preventDefault();
      console.log(e.target.value);
      fetch("http://127.0.0.1:3001/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log(data);
          alert("Item added successfully!");
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    }; // end handleOnSubmit

    //return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Form to input data */}
        <form onSubmit={handleSubmit}>
          <h1>Post a New Product</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // PUT - Modify an item
  const Putcatalog = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });
    console.log(formData);

    const handleChange = (e) => {
      console.log(formData);
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
      console.log(formData);
    };

    const handleSubmit = (e) => {
      console.log(formData);
      e.preventDefault();
      const id = formData.id; // Extract ID from formData
      fetch(`http://localhost:3001/change2/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(
              `PUT request failed with status ${response.status}`
            );
          }
          return response.json();
        })
        .then((data) => {
          console.log("PUT request successful:", data);
          alert("Item updated successfully!");
        })
        .catch((error) => {
          console.error("Error updating item:", error);
          alert("Error updating item: " + error.message); // Display alert if there's an error
        });
    };

    return (
      <div>
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <form onSubmit={handleSubmit}>
          <h1>Put (Modify) an Existing Product by ID</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <p>Enter an ID to be updated with your new information</p>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // DELETE - Delete an item
  const Deletecatalog = () => {
    // Define HOOKS
    const [products, setProducts] = useState([
      {
        id: "",
        title: "",
        price: "",
        description: "",
        category: "",
        image: "",
        Quantity: ""
      },
    ]);
    const [index, setIndex] = useState(0);
    const navigate = useNavigate();

    // useEffect to load catalog when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          setProducts(data);
          console.log("Load initial Catalog of Products in DELETE :", data);
        });
    }, []);

    // Function to review products like carousel
    function getOneByOneProductNext() {
      if (products.length > 0) {
        if (index === products.length - 1) setIndex(0);
        else setIndex(index + 1);
      }
    }

    function getOneByOneProductPrev() {
      if (products.length > 0) {
        if (index === 0) setIndex(products.length - 1);
        else setIndex(index - 1);
      }
    }

    // Delete de product by its id <- id is Hook
    const deleteOneProduct = (id) => {
        console.log("I am here");
      console.log("Product to delete :", id);
      fetch("http://localhost:3001/deleteone/" + id, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: id }),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log("Delete a product completed : ", id);
          console.log(data);
          // reload products from the local products array
          const newProducts = products.filter((product) => product.id !== id);
          setProducts(newProducts);
          setIndex(0);
          // show alert
          if (data) {
            const key = Object.keys(data);
            const value = Object.values(data);
            alert(key + value);
          }
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    };

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Buttons to simulate carousel */}
        <h3>Delete one product:</h3>
        <button onClick={() => getOneByOneProductPrev()}>Prev</button>
        <button onClick={() => getOneByOneProductNext()}>Next</button>
        <button onClick={() => deleteOneProduct(products[index].id)}>
          Delete
        </button>

        {/* Show product properties, one by one */}
        <div key={products[index].id}>
          <img src={products[index].image} alt="product" width={75} /> <br />
          Id:{products[index].id} <br />
          Title: {products[index].title} <br />
          Price: {products[index].price} <br />
          Description: {products[index].description} <br />
          Category: {products[index].category} <br />
          Quantity :{products[index].Quantity} <br />
        </div>
      </div>
    );
  };


  const Payment = () => {
    const navigate = useNavigate();

    return (
        <div>
          
                  
            <form onSubmit={handleSubmit(onSubmit)} className="container mt-5">
                {/* Payment Form */}
                
                <div className="form-group" >
                <div className="row main align-items-center">
                    <input {...register("fullName", { required: true })} placeholder="Full Name" className="form-control" />
                    {errors.fullName && <p className="text-danger">Full Name is required.</p>}
                    </div>
                </div><br />

                <div className="form-group">
                    <input {...register("email", { required: true, pattern: /^\S+@\S+$/i })} name="email" type="email" placeholder="Email" className="form-control" />
                    {errors.email && <p className="text-danger">Email is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("creditCard", { required: true})} placeholder="Credit Card" className="form-control" />
                    {errors.creditCard && <p className="text-danger">Credit Card is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address", { required: true })} placeholder="Address" className="form-control" />
                    {errors.address && <p className="text-danger">Address is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address2")} placeholder="Address 2" className="form-control" />
                </div><br />

                <div className="form-group">
                    <input {...register("city", { required: true })} placeholder="City" className="form-control" />
                    {errors.city && <p className="text-danger">City is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("state", { required: true })} placeholder="State" className="form-control" />
                    {errors.state && <p className="text-danger">State is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("zip", { required: true })} placeholder="Zip" required pattern="^\d{5}$" className="form-control"/>
                    {errors.zip && <p className="text-danger">Zip is required.</p>}
                </div><br />

                <button onClick={() => navigate("/ViewSummary")} className="btn btn-primary">Order</button>
                <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
            
                
           
            </form>
        </div>
    );
};



  const CartView = () => {
    console.log(cart);
    const allitems = Array.from(new Set(cart.map(el => el.id)))
        .map(id => {
            return {
                ...cart.find(el => el.id === id),
                quantity: cart.filter(el => el.id === id).length
            };
        });

    const cartItems = allitems.map((el, index) => (
        <div key={index}>
            <div className="row border-top border-bottom" key={el.id}>
                <div className="row main align-items-center">
                    <div className="col-1">
                        <img className="img-fluid" src={el.image} width={75} />
                    </div>
                    <div className="col-1">
                        <div className="row text-muted">{el.title}</div>
                        <div className="row">{el.category}</div>
                    </div>
                    <div className="col-1">
                        ${el.price} <span className="close">&#10005;</span> {el.quantity}
                    </div>
                </div>
            </div>
        </div>
    ));

    //displays items selected in browse, total price, and payment form
    return (
        <div>
            <h1><b>Shopping Cart</b></h1>
            <p>View your cart items</p>
            <p><strong>Order total: ${cartTotal}</strong></p>
            <div>{cartItems}</div><br />
            <h1><b>Payment:</b></h1>
            <Payment />
        </div>
    );
};


const ViewSummary = () => {
  const navigate = useNavigate();
  const allitems = Array.from(new Set(cart.map(el => el.id)))
      .map(id => {
          return {
              ...cart.find(el => el.id === id),
              quantity: cart.filter(el => el.id === id).length
          };
      });

  const cartItems = allitems.map((el, index) => (
      <div key={index}>
          <div className="row border-top border-bottom" key={el.id}>
              <div className="row main align-items-center">
                  <div className="col-1">
                      <img className="img-fluid" src={el.image} width={75} />
                  </div>
                  <div className="col-1">
                      <div className="row text-muted">{el.title}</div>
                      <div className="row">{el.category}</div>
                  </div>
                  <div className="col-1">
                      ${el.price} <span className="close">&#10005;</span> {el.quantity}
                  </div>
              </div>
          </div>
      </div>
  ));

 
  return (
      <div>
          <h1><b>Order summary</b></h1>
          <p><strong>Order total: ${cartTotal}</strong></p>

{/*         
          <h4>Payment summary:</h4>
          <p>{dataF.fullName}</p>
          <p>{dataF.email}</p>
          <p>{dataF.creditCard}</p>
          <p>{dataF.address}</p>
          <p>{dataF.address2}</p>
          <p>{dataF.city}, {dataF.state} {dataF.zip} </p><br /> */}

          <h4>Purchased:</h4>
          <div>{cartItems}</div><br />
          <button onClick={() => navigate("/CartView")} className="btn btn-primary">Back to Cart</button>
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
      </div>
  );
};


const JavaScript = () => {
  const navigate = useNavigate();
  return (
      <div>
         <h1>JavaScript</h1>
         <div id="stringimage">   
            <img src="./finalImages/javascriptphoto.png" width ="600" alt="code" ></img>
        </div> 
        <label><b>Javascript</b></label><br />
        <label>JavaScript, is a computer programming language that is used in the development of web portals and web APIs. It is used to create complex features used in websites and web applications. JavaScript is a scripting language, which means it is translated into machine code at runtime rather than when it is compiled. This means its an interpreted language.</label><br />
        

    <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
    </div>
  );
};



const Java = () => {
    const navigate = useNavigate();
    return (
        <div>
           <h1>Java</h1>
        <div id="stringimage">   
            <img src="./finalImages/javaphoto1.png" width ="400" alt="code" ></img>
        </div> 
        <div id="stringimage2">   
            <img src="./finalImages/javaphoto3.png" width ="600" alt="code2" ></img>
        </div> 
          <label><b>Java</b></label><br />
          <label><p> Java was the first language that combined methods using a Java Virtual Machine (JVM), which is the Java code compiler. This allows code into bytecode which can only run in the JVM.</p></label><br />
          <label><b>Reasons to choose Java</b></label><br />
          <label>It is smart to choose Java to write code since it is not native to any platform meaning it is platform independent. This allows an app written on a windows desktop to run on a Mac OS, a server or an embedded device without any issues and rather seamlessly. Additionally, Java is strongly typed and uses object-oriented programming as its core architecural design thus make the code written in it reliable and easy to maintainwhen it comes to enterprise wide large applications. Java also has an extnesive development kit and library that provides support during application development. Java also has an in-built memory manager that allows for efficient garbage collection and optimal execution and scalability of the application. Java is versatile and thus used globally in various projects.
          </label><br />
        


        <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
          
    );
};

const C = () => {
    const navigate = useNavigate();
    return (
        <div>
           <h1>C Programming</h1>
          <div id="stringimage">   
            <img src="./finalImages/cphoto1.jpg" width ="400" alt="code" ></img>
        </div> 
        <div id="stringimage">   
            <img src="./finalImages/cphoto3.jpg" width ="" alt="code" ></img>
        </div> 
          <label><b>C Programming</b></label><br />
          <label><p>C, is a stable language developed in the 1970s by Dennis M. Ritchie at AT&T. It was written for small operating systems initially.</p></label><br />
          <label><b>Reasons to choose C</b></label><br />
          <label>C is excellent when the developer required low-level control of the application which maintaining high performance. It is simple and efficient and thus is used extensively in system programming including in our course in CPRE 288 where we built an autonomous Roomba vaccum cleaner. C required very few resources to execute efficiently and uses an approach where there is no middle layer, it is thus defacto close to the hardware it runs on. It can thus manage and manipulate memory precisely and control resources of the system optimally. C is thus also a great language when creating device drivers or where real time systems such as flight controllers and pacemakers are involved. C has been adopted worldwide and has stood the test of time in the IT industry and has a large library and community of useful resources to back it up and support it. It is used in areas where the project is large and long term since it takes a while to write all the code from scratch to build a project, but it is powerful enough that it is still well respected amongst developers.</label><br />
          
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const MongoDB = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>MongoDB</h1>
          <div id="stringimage">   
            <img src="./finalImages/mongophoto.png" width ="1000" alt="code" ></img>
        </div> 
          <label><b>MongoDB</b></label><br />
          <label>MongoDB ia a user-friendly unstrucuted database that avoids many of the larger databases schema issues as it stores data in the NoSQL database. This underlying non-schema approach is appealing to those who want the flexibility of altering schema on the fly thus allowing the data model to be altered and reformatted without affecting the overlaying application.</label><br />
          
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const VisualBasic = () => {
    const navigate = useNavigate();
    return (
        <div>
           <h1>Visual Basic</h1>
           <div id="stringimage">   
            <img src="./finalImages/visualbasicphoto.png" width ="800" alt="code" ></img>
        </div> 
          <label><b>Visual Basic</b></label><br />
          <label><p>Visual Basic was introduced in 1991 by Microsoft. It uses event-driven programming, as an example do something on a button click. Visual Basic had a predecessor in BASIC language which mean "Beginners' All-purpose Symbolic Instruction Code". It was one of the first languages that was able to use modern english in code allowing developers to write code without needing to know assembly programming.</p></label><br />
          
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const SQL = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>SQL</h1>
          <div id="stringimage">   
              <img src="./finalImages/microsoftsqlphoto.png" width ="400" alt="code" ></img>
          </div> 
            <label><b>SQL</b></label><br />
            <label><p>Structured Query Language, is the largest giant in the world of databases. It is used to manipulate and access large and complex databases in normalized and relational form. thus allowing the use of tables in rows and columns format. With SQL statements, you can thus update, host, delete drop, and read information from the database. SQL language is used extensively to optimize database performance. </p></label><br />
            
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};

const HTML = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>HTML</h1>
          <div id="stringimage">   
            <img src="./finalImages/htmlphoto.jpg" width ="400" alt="code" ></img>
        </div> 
          <label>This is some sample HTML</label><br />
          <label><b><h1>This Heading was made using HTML</h1></b></label><br />
          <label>HTML</label><br />
          <label><p>Hyper Text Format Language, is used to format text such that the information (text, images, videos) can be displayed in any web browser over the internet. The data is retrieved into Web page (in reference to the world wide web), with a reference hypertext links thus allowing all related pages to be linked and accessed if clicked.</p></label><br />
          <label></label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};



const CSS = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>CSS</h1>
          <div id="stringimage">   
            <img src="./finalImages/cssphoto.jpg" width = "300" alt="code"></img>
        </div>    
          <label>This is some sample CSS</label><br />
          <label><b><div class="w3-white"><h2>CSS Example</h2><p>Cascading Style Sheets abbreviated as CSS. This is a language for stylesheets used to define document presentation that has been created in a markup language such as HTML. CSS is used extensively in websites development.</p></div></b></label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const Access = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>Access</h1>
          <div id="stringimage">   
            <img src="./finalImages/microsoftaccessphoto.png" width ="600" alt="code" ></img>
          </div> 
          <label><b>Microsoft Access</b></label><br />
         
          <label>Microsoft Access is an older database management system that was created by Microsoft. It is included in the Microsoft 365 Office suite. It uses a relational Jet DB Engine that includes a software development toolkit and a user interface for data manipulation. It was created in 1992. Information Technology is fast paced, thus this DB system is considered archaic</label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const Oracle = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>Oracle</h1>
          <div id="stringimage">   
            <img src="./finalImages/oraclephoto.png" width ="500" alt="code" ></img>
          </div> 
          <label><b>Oracle</b></label><br />
          <label>Oracle is a very large enterprise database system and many large corporation use Oracle as the backend for their databases. Oracle has stood the test of time and has improved year over year with many feature additons for quick data retrieval and memory management as hardware has improved exponentially over this period of time. It can be accessed from  many languages including C, C++, Java and Visual Basic. It supports  all standards in all languages. It even exposes API's and Call Interface via libraries for developers to interact with if their application architecture so demands.</label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};



const Python = () => {
    const navigate = useNavigate();
    return (
        <div>
          <h1>Python</h1>
           <div id="stringimage">   
            <img src="./finalImages/pythonphoto.png" width ="600" alt="code" ></img>
          </div> 
          <div id="stringimage">   
            <img src="./finalImages/pythonphoto2.png" width ="600" alt="code" ></img>
          </div> 
          <label><b>Python</b></label><br />
          <label>Python is a general-purpose programming language that is high-level and used extensively in the world of machine learning and big data. It is known for code readability and maintainability. It requires lesser lines of code due to its simplified syntax. It allows faster integration of code with various systems.</label><br />
          <label><b>Reason to choose Python</b></label><br />
          <label>
          If you choose Python for programming, there are numerous advantages, especially considering how simple and versatile it is. It has a clean syntax and easy to understand entities and methose thus allowing programmers to write efficient code, further enhancing the code's maintainance. It has an extensive library that include third-party packages that help solve a wide range of tasks, including data science, data analytics, AI and scientific computing. Python allows for static and dynamic typing which includes integration with .Net's automated memory management thus promoting a streamlined apporach to memory caching and garbage collection, which gives programmers the liberty to focus on high level issues as Python takes care of lower level OS level details seamlessly. It is easy for new programmers to learn. It scales and performs gracefully since it is supported by the powerful TensorFlow library, making it appropriate in large-scale projects. Developers are able to create quick prototype ideas and build robust applications.</label><br />
    <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};




const AboutUs = () => {
    const navigate = useNavigate();
    return (
        <div className="center"><br/><br/>
            <label><b>SE 319 Construction of User Interfaces, Spring 2024</b></label>
            <br></br>
            <label><b>April 30 2024</b></label>
            <br></br>
          <label><b>By Ozair Nurani and Reza Choudhury </b></label><br />
          <label>Code Crafters</label><br />
          <label>We are both sophomores majoring in Software Engineering</label><br />
          <label>onurani@iastate.edu and zaza@iastate.edu</label><br /><br />
          <label>Name of Instructor: Dr. Abraham N. Aldaco Gastelum</label><br /><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>  
        </div>
    );
  };
  

  return (
    <Router>
      <Routes>
        <Route path="/getcatalog" element={<Getcatalog />} />
        <Route path="/getcatalogid" element={<Getcatalogid />} />
        <Route path="/postcatalog" element={<Postcatalog />} />
        <Route path="/putcatalog" element={<Putcatalog />} />
        <Route path="/deletecatalog" element={<Deletecatalog />} />
        <Route path="/CartView" element={<CartView />} />
        <Route path="/ViewSummary" element={<ViewSummary />} />
        <Route path="/JavaScript" element={<JavaScript />} />
        <Route path="/Java" element={<Java />} />
        <Route path="/C" element={<C />} />
        <Route path="/MongoDB" element={<MongoDB />} />
        <Route path="/VisualBasic" element={<VisualBasic />} />
        <Route path="/SQL" element={<SQL />} />
        <Route path="/HTML" element={<HTML />} />
        <Route path="/CSS" element={<CSS />} />
        <Route path="/Access" element={<Access />} />
        <Route path="/Oracle" element={<Oracle />} />
        <Route path="/Python" element={<Python />} />
        <Route path="/AboutUs" element={<AboutUs />} />
        <Route path="/" element={<Getcatalog />} /> {/* Default view */}
      </Routes>
    </Router>
  );
} // App end

export default App;