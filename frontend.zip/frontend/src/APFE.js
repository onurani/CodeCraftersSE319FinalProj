//Author: Ozair Nurani
//ISU Netid : onurani@iastate.edu
//Date :  April 26, 2024

import { useState, useEffect } from "react";
import "./App.css";
import { useForm } from "react-hook-form";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";

function App() {
  // GET all items
  const [dataF, setDataF] = useState({});
  const [view, setView] = useState("browse");
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [cart, setCart] = useState([]);
  const [cartTotal, setCartTotal] = useState(0);
    
  const onSubmit = (data) => {
      setDataF(data); 
      setView("ViewSummary");
  };
  
  const updateHooks = () => {
      setView("Getcatalog");
      setDataF({});
      setCart([]);
  };

  const addToCart = (el) => {  
    setCart([...cart, el]);
};

const removeFromCart = (el) => {
    let updatedItem = [...cart];
    updatedItem = updatedItem.filter((cartItem) => cartItem.id !== el.id);
    setCart(updatedItem);
    let itemFound = false;
    const updatedCart = cart.filter((cartItem) => {
        if (cartItem.id === el.id && !itemFound) {
            itemFound = true;
            return false;
        }
        return true;
    });
    if (itemFound) {
        setCart(updatedCart);
    }
};

function howManyofThis(id) {
    let returner = cart.filter((cartItem) => cartItem.id === id);
    return returner.length;
}

const total = () => {
  let totalVal = 0;
  for (const item of cart) {
      totalVal += item.price;
  }
  setCartTotal(totalVal);
};

useEffect(() => {
total();
}, [cart]);

  const Getcatalog = () => {
    // Define hooks
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    //const [cart, setCart] = useState(currqntty?.innerHTML);
    
    // useEffect to load products when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          console.log("Show Catalog of Products :", data);
          setProducts(data);
        });
    }, []);

    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <button onClick={() => navigate("/AboutUs")}>
          About Us
        </button>


        {/* Show all products using map */}
        {products.map((el) => (
          
          <div key={el.id}>
            <img src={el.image} alt="product" width={75} />
            <div><button onClick={() => navigate(`/${el.title}`)} className="btn btn-secondary">GoToCourse</button></div>
            
            <div><b>Title</b>: {el.title} <br /></div>
            
            <div><b>Price</b>: {el.price}</div>
            <div><b>Description</b>: {el.description}</div>
            <div><b>Category</b>: {el.category}</div>
            <div className="col">
                        <button type="button" variant="light" onClick={() => removeFromCart(el)} > - </button>{" "}
                        <button type="button" variant="light" onClick={() => addToCart(el)}> + </button>
            </div>
            <div className="col">
                        ${el.price} <span className="close">&#10005;</span> {howManyofThis(el.id)}
                    </div><br /><br />
          </div>
        ))}
        <button onClick={() => navigate("/CartView")} className="btn btn-primary">Checkout</button><br /><br /><br />
      </div>
    );
  };


  /*
  // GET one item
  const Getcatalogid = () => {
    // Define hooks
    const [oneProduct, setOneProduct] = useState([]);
    const navigate = useNavigate();
    const [id, setId] = useState("");

    // useEffect to load catalog once HOOK id is modified
    useEffect(() => {
      if (id) {
        fetch(`http://127.0.0.1:3001/language/${id}`)
          .then((response) => response.json())
          .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
          });
      }
    }, [id]); // Fetch only when id changes

    // return
    return (
      <div>
        {}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <br />
        <input
          type="text"
          placeholder="Enter ID"
          onChange={(e) => setId(e.target.value)}
        />

        {}
        {oneProduct.map((el) => (
          <div key={el.id}>
            <img src={el.image} alt="product" width={75} />
            <div><b>Title</b>: {el.title}</div>
            <div><b>Price</b>: {el.price}</div>
            <div><b>Description</b>: {el.description}</div>
            <div><b>Category</b>: {el.category}</div>
            <div><b>Quantity</b>: {el.Quantity}</div>
          </div>
        ))}
      </div>
    );
  };
  */



  const Getcatalogid = () => {
    // Define hooks
    const [oneProduct, setOneProduct] = useState({});
    const navigate = useNavigate();
    const [id, setId] = useState("");

    // useEffect to load catalog once HOOK id is modified
    useEffect(() => {
      if (id) {
        fetch(`http://127.0.0.1:3001/language/${id}`)
          .then((response) => response.json())
          .then((data) => {
            console.log("Show one product :", data);
            setOneProduct(data);
          });
      }
    }, [id]); // Fetch only when id changes

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>GET Item by Id</button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <br />
        <input
          type="text"
          placeholder="Enter ID"
          onChange={(e) => setId(e.target.value)}
        />

        {/* Show one product using map */}
        {<div key={oneProduct.id}>
            <img src={oneProduct.image} alt="product" width={75} />
            <div>Title: {oneProduct.title}</div>
            <div>Category: {oneProduct.category}</div>
            <div>Price: {oneProduct.price}</div>
            <div>Quantity: {oneProduct.Quantity}</div>
          </div>
        }
      </div>
    );
  };

  // POST a new item
  const Postcatalog = () => {
    // Define HOOKS
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });

    // Function to add input in formData HOOK using operator ...
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    };

    // Function to fetch backend for POST - it sends data in BODY
    const handleSubmit = (e) => {
      e.preventDefault();
      console.log(e.target.value);
      fetch("http://127.0.0.1:3001/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log(data);
          alert("Item added successfully!");
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    }; // end handleOnSubmit

    //return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Form to input data */}
        <form onSubmit={handleSubmit}>
          <h1>Post a New Product</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // PUT - Modify an item
  const Putcatalog = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
      id: "",
      title: "",
      price: "",
      description: "",
      category: "",
      image: "",
      Quantity: "",
    });
    console.log(formData);

    const handleChange = (e) => {
      console.log(formData);
      const { name, value } = e.target;
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
      console.log(formData);
    };

    const handleSubmit = (e) => {
      console.log(formData);
      e.preventDefault();
      const id = formData.id; // Extract ID from formData
      fetch(`http://localhost:3001/change2/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(
              `PUT request failed with status ${response.status}`
            );
          }
          return response.json();
        })
        .then((data) => {
          console.log("PUT request successful:", data);
          alert("Item updated successfully!");
        })
        .catch((error) => {
          console.error("Error updating item:", error);
          alert("Error updating item: " + error.message); // Display alert if there's an error
        });
    };

    return (
      <div>
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>
        <form onSubmit={handleSubmit}>
          <h1>Put (Modify) an Existing Product by ID</h1>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            placeholder="ID"
            required
          />{" "}
          <br />
          <p>Enter an ID to be updated with your new information</p>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Title"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            placeholder="Category"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            placeholder="Image URL"
            required
          />{" "}
          <br />
          <input
            type="text"
            name="Quantity"
            value={formData.Quantity}
            onChange={handleChange}
            placeholder="Quantity"
            required
          />{" "}
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  };

  // DELETE - Delete an item
  const Deletecatalog = () => {
    // Define HOOKS
    const [products, setProducts] = useState([
      {
        id: "",
        title: "",
        price: "",
        description: "",
        category: "",
        image: "",
        Quantity: ""
      },
    ]);
    const [index, setIndex] = useState(0);
    const navigate = useNavigate();

    // useEffect to load catalog when load page
    useEffect(() => {
      fetch("http://127.0.0.1:3001/language")
        .then((response) => response.json())
        .then((data) => {
          setProducts(data);
          console.log("Load initial Catalog of Products in DELETE :", data);
        });
    }, []);

    // Function to review products like carousel
    function getOneByOneProductNext() {
      if (products.length > 0) {
        if (index === products.length - 1) setIndex(0);
        else setIndex(index + 1);
      }
    }

    function getOneByOneProductPrev() {
      if (products.length > 0) {
        if (index === 0) setIndex(products.length - 1);
        else setIndex(index - 1);
      }
    }

    // Delete de product by its id <- id is Hook
    const deleteOneProduct = (id) => {
        console.log("I am here");
      console.log("Product to delete :", id);
      fetch("http://localhost:3001/deleteone/" + id, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: id }),
      })
        .then((response) => {
          if (response.status != 200) {
            return response.json().then((errData) => {
              throw new Error(
                `POST response was not ok :\n Status:${response.status}. \n Error: ${errData.error}`
              );
            });
          }
          return response.json();
        })
        .then((data) => {
          console.log("Delete a product completed : ", id);
          console.log(data);
          // reload products from the local products array
          const newProducts = products.filter((product) => product.id !== id);
          setProducts(newProducts);
          setIndex(0);
          // show alert
          if (data) {
            const key = Object.keys(data);
            const value = Object.values(data);
            alert(key + value);
          }
        })
        .catch((error) => {
          console.error("Error adding item:", error);
          alert("Error adding robot:" + error.message); // Display alert if there's an error
        });
    };

    // return
    return (
      <div>
        {/* Buttons to show CRUD */}
        <button onClick={() => navigate("/getcatalog")}>GET Catalog</button>
        <button onClick={() => navigate("/getcatalogid")}>
          GET Item by Id
        </button>
        <button onClick={() => navigate("/postcatalog")}>
          POST a new Item
        </button>
        <button onClick={() => navigate("/putcatalog")}>
          PUT (modify) an Item
        </button>
        <button onClick={() => navigate("/deletecatalog")}>
          DELETE an Item
        </button>

        {/* Buttons to simulate carousel */}
        <h3>Delete one product:</h3>
        <button onClick={() => getOneByOneProductPrev()}>Prev</button>
        <button onClick={() => getOneByOneProductNext()}>Next</button>
        <button onClick={() => deleteOneProduct(products[index].id)}>
          Delete
        </button>

        {/* Show product properties, one by one */}
        <div key={products[index].id}>
          <img src={products[index].image} alt="product" width={75} /> <br />
          Id:{products[index].id} <br />
          Title: {products[index].title} <br />
          Price: {products[index].price} <br />
          Description: {products[index].description} <br />
          Category: {products[index].category} <br />
          Quantity :{products[index].Quantity} <br />
        </div>
      </div>
    );
  };


  const Payment = () => {
    const navigate = useNavigate();

    return (
        <div>
            <form onSubmit={handleSubmit(onSubmit)} className="container mt-5">
                {/* Payment Form */}
                <div className="form-group">
                    <input {...register("fullName", { required: true })} placeholder="Full Name" className="form-control" />
                    {errors.fullName && <p className="text-danger">Full Name is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("email", { required: true, pattern: /^\S+@\S+$/i })} name="email" type="email" placeholder="Email" className="form-control" />
                    {errors.email && <p className="text-danger">Email is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("creditCard", { required: true})} placeholder="Credit Card" className="form-control" />
                    {errors.creditCard && <p className="text-danger">Credit Card is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address", { required: true })} placeholder="Address" className="form-control" />
                    {errors.address && <p className="text-danger">Address is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("address2")} placeholder="Address 2" className="form-control" />
                </div><br />

                <div className="form-group">
                    <input {...register("city", { required: true })} placeholder="City" className="form-control" />
                    {errors.city && <p className="text-danger">City is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("state", { required: true })} placeholder="State" className="form-control" />
                    {errors.state && <p className="text-danger">State is required.</p>}
                </div><br />

                <div className="form-group">
                    <input {...register("zip", { required: true })} placeholder="Zip" required pattern="^\d{5}$" className="form-control"/>
                    {errors.zip && <p className="text-danger">Zip is required.</p>}
                </div><br />

                <button onClick={() => navigate("/ViewSummary")} className="btn btn-primary">Order</button>
                <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
            </form>
        </div>
    );
};



  const CartView = () => {
    console.log(cart);
    const allitems = Array.from(new Set(cart.map(el => el.id)))
        .map(id => {
            return {
                ...cart.find(el => el.id === id),
                quantity: cart.filter(el => el.id === id).length
            };
        });

    const cartItems = allitems.map((el, index) => (
        <div key={index}>
            <div className="row border-top border-bottom" key={el.id}>
                <div className="row main align-items-center">
                    <div className="col-1">
                        <img className="img-fluid" src={el.image} width={75} />
                    </div>
                    <div className="col-1">
                        <div className="row text-muted">{el.title}</div>
                        <div className="row">{el.category}</div>
                    </div>
                    <div className="col-1">
                        ${el.price} <span className="close">&#10005;</span> {el.quantity}
                    </div>
                </div>
            </div>
        </div>
    ));

    //displays items selected in browse, total price, and payment form
    return (
        <div>
            <h1><b>Shopping Cart</b></h1>
            <p>View your cart items</p>
            <p><strong>Order total: ${cartTotal}</strong></p>
            <div>{cartItems}</div><br />
            <h1><b>Payment:</b></h1>
            <Payment />
        </div>
    );
};


const ViewSummary = () => {
  const navigate = useNavigate();
  const allitems = Array.from(new Set(cart.map(el => el.id)))
      .map(id => {
          return {
              ...cart.find(el => el.id === id),
              quantity: cart.filter(el => el.id === id).length
          };
      });

  const cartItems = allitems.map((el, index) => (
      <div key={index}>
          <div className="row border-top border-bottom" key={el.id}>
              <div className="row main align-items-center">
                  <div className="col-1">
                      <img className="img-fluid" src={el.image} width={75} />
                  </div>
                  <div className="col-1">
                      <div className="row text-muted">{el.title}</div>
                      <div className="row">{el.category}</div>
                  </div>
                  <div className="col-1">
                      ${el.price} <span className="close">&#10005;</span> {el.quantity}
                  </div>
              </div>
          </div>
      </div>
  ));

 
  return (
      <div>
          <h1><b>Order summary</b></h1>
          <p><strong>Order total: ${cartTotal}</strong></p>

{/*         
          <h4>Payment summary:</h4>
          <p>{dataF.fullName}</p>
          <p>{dataF.email}</p>
          <p>{dataF.creditCard}</p>
          <p>{dataF.address}</p>
          <p>{dataF.address2}</p>
          <p>{dataF.city}, {dataF.state} {dataF.zip} </p><br /> */}

          <h4>Purchased:</h4>
          <div>{cartItems}</div><br />
          <button onClick={() => navigate("/CartView")} className="btn btn-primary">Back to Cart</button>
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button><br /><br /><br />
      </div>
  );
};


const JavaScript = () => {
  const navigate = useNavigate();
  return (
      <div>
         <div id="stringimage">   
            <img src="./finalImages/javascriptphoto.png" width ="600" alt="code" ></img>
        </div> 
        <label><b>Javascript</b></label><br />
        <label>JavaScript, computer programming language that is a mainstay of web development, enabling the creation of complex features and interactivity in websites and web applications, as well as other use cases. JavaScript is a scripting language, meaning that its code is interpreted (i.e., translated into machine code) at runtime rather than when it is compiled by an application or engine.</label><br />
        
       
       





        <div id="content" class="container mt-4">
        <div id="math-question">
            <h2>Math Question</h2>
            
                <label for="user-inputx">let x = </label>
                <input type="number" id="user-inputx" required></input>
                <label for="user-inputy">let y = </label>
                <input type="number" id="user-inputy" required></input>
                <label for="javascriptmath">Operation</label>
                <select id="javascriptmath"></select>
                <button type="submit">Calculate</button>
          
            <div id="math-result">
                Result: <span id="math-result-val"></span>
            </div>
            <div id="mathimage">   
                <img src="./myotherimages/javascriptmathlogo.jpg" alt="Math Equation"></img>
            </div>    
            <div id="mathver">
                
            </div>
            <div id="moremath">
                
            </div>
        </div>

        
        <div id="string-question" class="mt-4">
            <h2>String Question</h2>
            
                <label for="user-stringinputx">Please input a word: </label>
                <input type="text" id="user-stringinputx" required></input>
                <label for="javascriptstring">Operation</label>
                <select id="javascriptstring"></select>
                <button type="submit">Evaluate</button>
          
            <div id="string-result">
                Result: <span id="string-result-val"></span>
            </div>
            <div id="stringimage">   
                <img src="./myotherimages/javascriptstringlogo.jpg" alt="String Equation"></img>
            </div>    
            <div id="stringver">
                
            </div>
            <div id="morestring">
                
            </div>
        </div>
    </div>


    <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
    </div>
  );
};



const Java = () => {
    const navigate = useNavigate();
    return (
        <div>

        <div id="stringimage">   
            <img src="./finalImages/javaphoto1.png" width ="400" alt="code" ></img>
        </div> 
        <div id="stringimage2">   
            <img src="./finalImages/javaphoto2.jpg" width ="400" alt="code2" ></img>
        </div> 
          <label><b>Java</b></label><br />
          <label><p>The Java program was the first language to combine both methods above using a Java Virtual Machine (JVM). The Java code compiler is called the Java Virtual Machine. Any Java file is first compiled into bytecode. Java bytecode can only run in the JVM.</p></label><br />
          
          







        <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
          
    );
};

const C = () => {
    const navigate = useNavigate();
    return (
        <div>
          <div id="stringimage">   
            <img src="./finalImages/cphoto1.jpg" width ="400" alt="code" ></img>
        </div> 
        <div id="stringimage">   
            <img src="./finalImages/cphoto3.jpg" width ="" alt="code" ></img>
        </div> 
          <label><b>C Programming</b></label><br />
          <label><p>C, computer programming language developed in the early 1970s by American computer scientist Dennis M. Ritchie at Bell Laboratories (formerly AT&T Bell Laboratories). C was designed as a minimalist language to be used in writing operating systems for minicomputers, such as the DEC PDP 7</p></label><br />
      
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const MongoDB = () => {
    const navigate = useNavigate();
    return (
        <div>
          <div id="stringimage">   
            <img src="./finalImages/mongophoto.png" width ="1000" alt="code" ></img>
        </div> 
          <label><b>MongoDB</b></label><br />
          <label>MongoDB is free of schema problems. It is possible to store data in the NoSQL database without the need to use a predefined schema, which means you can alter the model of data and format without affecting applications. It's user-friendly.</label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const VisualBasic = () => {
    const navigate = useNavigate();
    return (
        <div>
           <div id="stringimage">   
            <img src="./finalImages/visualbasicphoto.png" width ="800" alt="code" ></img>
        </div> 
          <label><b>Visual Basic</b></label><br />
          <label><p>Microsoft introduced VB in 1991, and it's considered the third generation of event-driven programming languages. VB is derived from BASIC, which stands for "Beginners' All-purpose Symbolic Instruction Code". BASIC was one of the first programming languages to use everyday words in the syntax, making it easier to learn and remember.</p></label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const SQL = () => {
    const navigate = useNavigate();





  





    return (
      /*
        <div>
          <div id="stringimage">   
            <img src="./finalImages/microsoftsqlphoto.png" width ="800" alt="code" ></img>
        </div> 
          <label><b>Microsoft SQL</b></label><br />
          <label>If you want to return all columns, without specifying every column name, you can use the SELECT * syntax:</label><br />
          
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
      */

          <div>

          <div id="stringimage">   
              <img src="./finalImages/javaphoto1.png" width ="400" alt="code" ></img>
          </div> 
          <div id="stringimage2">   
              <img src="./finalImages/javaphoto2.jpg" width ="400" alt="code2" ></img>
          </div> 
            <label><b>Java</b></label><br />
            <label><p>The Java program was the first language to combine both methods above using a Java Virtual Machine (JVM). The Java code compiler is called the Java Virtual Machine. Any Java file is first compiled into bytecode. Java bytecode can only run in the JVM.</p></label><br />
            
            
  
  
  
  
  
  
  
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
            </div>
            

    );
    

};

const HTML = () => {
    const navigate = useNavigate();
    return (
        <div>
          <div id="stringimage">   
            <img src="./finalImages/htmlphoto.jpg" width ="400" alt="code" ></img>
        </div> 
          <label>This is some sample HTML</label><br />
          <label><b><h1>Thsi Heading was made using HTML</h1></b></label><br />
          <label>HTML</label><br />
          <label><p>HTML, a formatting system for displaying material retrieved over the Internet. Each retrieval unit is known as a Web page (from World Wide Web), and such pages frequently contain hypertext links that allow related pages to be retrieved.</p></label><br />
          <label></label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};



const CSS = () => {
    const navigate = useNavigate();
    return (
        <div>
          <div id="stringimage">   
            <img src="./finalImages/cssphoto.jpg" alt="code"></img>
        </div>    
          <label>This is some sample CSS</label><br />
          <label><b><div class="w3-white"><h2>CSS Example</h2><p>CSS stands for Cascading Style Sheets.This style sheet language is used for defining the presentation of a document written in some markup language like HTML. CSS has now become a very important part of building blogs and websites.</p></div></b></label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const Access = () => {
    const navigate = useNavigate();
    return (
        <div>
          <div id="stringimage">   
            <img src="./finalImages/microsoftaccessphoto.png" width ="800" alt="code" ></img>
          </div> 
          <label><b>Microsoft Access</b></label><br />
         
          <label>Microsoft Access is a well-known database management system produced by Microsoft and is part of the Microsoft 365 office suite. Microsoft Access combines Microsoft’s relational Jet Database Engine with software development tools and a graphic user interface (GUI). It was first released in November 1992, so it’s been around for a while. In the rapidly changing, fast-paced IT world, we can best describe a 30-year-old program as "venerable."</label><br />
          
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};


const Oracle = () => {
    const navigate = useNavigate();
    return (
        <div>
          <label><b>This is some sample Oracle</b></label><br />
          <label>If you want to return all columns, without specifying every column name, you can use the SELECT * syntax:</label><br />
          <label><b>SELECT * FROM Customers;</b></label><br />
          <label>Return all the columns from the Customers table:</label><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>
          </div>
    );
};



const Python = () => {
    const navigate = useNavigate();
    return (
        <div>
          <label><b>This is some sample Python</b></label><br />
          <label><b>x = 1.10</b></label><br />
          <label><b>print(type(x));</b></label><br />
          <label>This prints x as 1.10</label><br />
         








          <div id="content" class="container mt-4">
        <div id="math-question">
            <h2>Math Question</h2>
            
                <label for="user-inputx">x = </label>
                <input type="number" id="user-inputx" required></input>
                <label for="user-inputy">y = </label>
                <input type="number" id="user-inputy" required></input>
                <label for="pythonmath">Operation</label>
                <select id="pythonmath"></select>
                <button type="submit">Calculate</button>
            
            <div id="math-result">
                Result: <span id="math-result-val"></span>
            </div>
            <div id="mathimage">   
                <img src="./myotherimages/pythonmathlogo.jpg" alt="Math Equation"></img>
            </div>    
            <div id="mathver">
            </div>
            <div id="moremath">

            </div>
            </div>

        <div id="string-question" class="mt-4">
            <h2>String Question</h2>
            <form id="string-form">
                <label for="user-stringinputx">Please input a word: </label>
                <input type="text" id="user-stringinputx" required></input>
                <label for="pythonstring">Operation</label>
                <select id="pythonstring"></select>
                <button type="submit">Evaluate</button>
            </form>
            <div id="string-result">
                Result: <span id="string-result-val"></span>
            </div>
            <div id="stringimage">   
                <img src="./myotherimages/pythonstringslogo.jpg" alt="String Equation"></img>
            </div>    
            <div id="stringver">
                
            </div>
            <div id="morestring">
                
            </div>
        </div>
    </div>

    <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>








          </div>
    );
};




const AboutUs = () => {
    const navigate = useNavigate();
    return (
        <div className="center"><br/><br/>
            <label><b>SE 319 Construction of User Interfaces, Spring 2024</b></label>
            <br></br>
            <label><b>April 30 2024</b></label>
            <br></br>
          <label><b>By Ozair Nurani and Reza Choudhury </b></label><br />
          <label>Code Crafters</label><br />
          <label>We are both sophomores majoring in Software Engineering</label><br />
          <label>onurani@iastate.edu and zaza@iastate.edu</label><br /><br />
          <label>Name of Instructor: Dr. Abraham N. Aldaco Gastelum</label><br /><br />
          <button onClick={() => navigate("/Getcatalog")} className="btn btn-secondary">Back to Browse</button>  
        </div>
    );
  };
  

  return (
    <Router>
      <Routes>
        <Route path="/getcatalog" element={<Getcatalog />} />
        <Route path="/getcatalogid" element={<Getcatalogid />} />
        <Route path="/postcatalog" element={<Postcatalog />} />
        <Route path="/putcatalog" element={<Putcatalog />} />
        <Route path="/deletecatalog" element={<Deletecatalog />} />
        <Route path="/CartView" element={<CartView />} />
        <Route path="/ViewSummary" element={<ViewSummary />} />
        <Route path="/JavaScript" element={<JavaScript />} />
        <Route path="/Java" element={<Java />} />
        <Route path="/C" element={<C />} />
        <Route path="/MongoDB" element={<MongoDB />} />
        <Route path="/VisualBasic" element={<VisualBasic />} />
        <Route path="/SQL" element={<SQL />} />
        <Route path="/HTML" element={<HTML />} />
        <Route path="/CSS" element={<CSS />} />
        <Route path="/Access" element={<Access />} />
        <Route path="/Oracle" element={<Oracle />} />
        <Route path="/Python" element={<Python />} />
        <Route path="/AboutUs" element={<AboutUs />} />
        <Route path="/" element={<Getcatalog />} /> {/* Default view */}
      </Routes>
    </Router>
  );
} // App end

export default App;