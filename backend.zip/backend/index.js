//Author: Ozair Nurani
//ISU Netid : onurani@iastate.edu
//Date :  May 5, 2024

var express = require("express");
var cors = require("cors");
var app = express();
var bodyParser = require("body-parser");
app.use(cors());
app.use(bodyParser.json());
const port = "3001";
const host = "localhost";
const {MongoClient} = require("mongodb");

const url = "mongodb://127.0.0.1:27017";
const dbName = "finalproj";
const client = new MongoClient(url);
const db = client.db(dbName);

app.get("/language", async (req, res) => {
    await client.connect();
    const query = {};
    const results = await db.collection("codinglanguages").find(query).limit(100).toArray();
    console.log(results);
    res.status(200).send(results);
});

app.get("/languageorginal/:id", async (req, res) => {
    const itemid = Number(req.params.id);
    await client.connect();
    const query = {"id": itemid };
    const results = await db.collection("codinglanguages").findOne(query);
    console.log("Results :", results);
    if (!results) res.send("Not Found").status(404);
    else res.send(results).status(200);
});


app.get("/language/:id", async (req, res) => {
    try {
      // Read id from frontend
      const id = Number(req.params.id);
      const query = {"id": id };
    const results = await db.collection("codinglanguages").findOne(query);
      console.log("Success in Reading MySQL");
      res.status(200).send(results);
    } catch (err) {
      // If an error occurs, catch it and send an appropriate error response
      console.error("Error in Reading MySQL :", err);
      res.status(500).send({ error: "An error occurred while fetching items." });
    }
  });



app.put("/change/:id", async (req, res) => {
    try{
        await client.connect();
        const itemid = parseInt(req.params.id);
        const values = Object.values(req.body);
        const results = await db.collection("codinglanguages").updateOne({id: itemid}, {$set:{price:values[1]}});
        res.status(200).send(results);
    } catch(error) {
        console.error("An error occurred: ", error);
        res.status(500).send({error: 'An internal server error occurred'});
    }
});


app.put("/change2/:id", async (req, res) => {
    try{
        await client.connect();
        const itemid = parseInt(req.params.id);
        const values = Object.values(req.body);
        const results = await db.collection("codinglanguages").updateOne({id: itemid},[{$set:{title:values[1],price:+values[2],description:values[3], category:values[4]}}]);
        res.status(200).send(results);
    } catch(error) {
        console.error("An error occurred: ", error);
        res.status(500).send({error: 'An internal server error occurred'});
    }
});



app.put("/changeproduct/:id", async (req, res) => {
    console.log("LOL")
    try {
        // Validate if body contains data
        if (!req.body || Object.keys(req.body).length === 0) {
            const msg = "PUT: Bad request: No data provided.";
            console.log(msg);
            return res.status(400).send({ error: msg });
        }

        const itemId = req.params.id; // Extract item ID from URL parameter

        // Check if the 'product' exists
        const [productExists] = await db.query("SELECT * FROM codinglanguages WHERE id = ?", [itemId]);
        if (productExists.length === 0) {
            // Item does not exist
            const msg = "PUT: Item does not exist";
            console.log(msg);
            return res.status(404).send({ error: msg });
        }

        // Proceed to update item
        const { title, price, description, category, image, Quantity } = req.body;
        const updateSql = "UPDATE codinglanguages SET title = ?, price = ?, description = ?, category = ?, image = ?, Quantity = ? WHERE id = ?";
        const updateResult = await db.query(updateSql, [title, price, description, category, image, Quantity, itemId]);

        // success
        const msg = "PUT: Success in updating MongoDB";
        console.log(msg);
        return res.status(200).send({ success: msg });

    } catch (err) {
        // Handle any error
        const msg = "PUT: An ERROR occurred in Update" + err;
        console.error(msg);
        res.status(500).send({ error: msg });
    }
});



app.delete("/deleteone/:id", async (req, res) => {
    try{
        
        await client.connect();
        const itemid = parseInt(req.params.id);
        console.log("DELETE DELETE DELETE ", itemid);
        console.log(typeof itemid);

        const results = await db.collection("codinglanguages").deleteMany({id: itemid});

        res.status(200).send(results);
    } catch(error) {
        console.error("An error occurred: ", error);
        res.status(500).send({error: 'An internal server error occurred'});
    }
})


app.post("/create", async (req, res) => {
    try{
        await client.connect();
        const values = Object.values(req.body);

        const newDocument = {
            "id": +values[0],
            "title": values[1],
            "price": +values[2],
            "description": values[3],
            "category": values[4],
            "image": values[5],
            "Quantity": +values[6]
        }

        console.log(newDocument);

        const results = await db.collection("codinglanguages").insertOne(newDocument);

        res.status(200).send(results);
    } catch(error) {
        console.error("An error occurred: ", error);
        res.status(500).send({error: 'An internal server error occurred'});
    }
});


app.listen(port, () => {
    console.log("App listening at http://%s:%s", host, port);
    });